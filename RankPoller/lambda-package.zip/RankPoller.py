import json
import requests

def lambda_handler(event, context):

    # The URL of the JSON file
    url = "https://pokemonshowdown.com/users/thebrucey.json"
    
    # Send a GET request to fetch the JSON data
    response = requests.get(url)
    
    # Check if the request was successful
    if response.status_code == 200:
        # Parse the response as JSON
        data = response.json()
        # Print the JSON data
        print(data)
    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")
    
    return {
        'statusCode': 200,
        'body': data
    }

if __name__ == '__main__': 
    print(lambda_handler("","")) 